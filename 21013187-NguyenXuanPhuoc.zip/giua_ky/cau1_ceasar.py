class ceasar:
    def __init__(self,k:int):

        self.k  = k

        self.map = {}

        self.char = "abcdefghijklmnopqrstuvwxyz"

        for i, char in enumerate(self.char):
            self.map[char] = i

        self.n = len(self.map)

    def encode(self,p:str):

        encode = ""
        for i,char in enumerate(p.lower()):

            if char not in self.map.keys():
                encode+= char
                continue

            value = (self.map[char] + self.k) % self.n

            encode += self.char[value]

        return encode

    def decode(self, e):

        p = ""
        for i, char in enumerate(e.lower()):

            if char not in self.map.keys():
                p += char
                continue

            value = (self.map[char] - self.k)

            p+= self.char[(value+self.n)%self.n]
        return p

encode = "ehkraldajegww"
d = {
    'love':1,
    'and':1,
    'uni':1,
}

for i in range(1,26):

    model = ceasar(i)
    decode = model.decode(encode)

    leng = len(decode)

    for key in d.keys():
        if key in decode:
            print(f"khoa k {i} tim thay text co y nghia: {decode}")
            break

